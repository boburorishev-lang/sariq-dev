"""
27/11/2020
Dasturlash asoslari
#12-dars: Xatolar
Muallif: Anvar Narzullaev
Web sahifa: https://python.sariq.dev
"""

users = ['alisher1983','aziza','yasina','umar']

login = input("Yangi login tanlang: ")

if login.lower in users:
    print('Login band, yangi login tanalng!')
else:
    print("Xush kelibsiz!")