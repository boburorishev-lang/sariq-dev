"""
27/11/2020
Dasturlash asoslari
#12-dars: Xatolar
Muallif: Anvar Narzullaev
Web sahifa: https://python.sariq.dev
"""

son = float(input("Juft son kiriting: "))
if son%2!=0:
    print("Bu son juft emas.")
else:
    print("Rahmat!")